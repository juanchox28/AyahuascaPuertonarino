#!/bin/bash
# ------------------------------------------------------------------
# Startup script para Hotel Paradise con logging completo
# ------------------------------------------------------------------

LOG_FILE="$HOME/Escritorio/hotel-booking/logs.txt"

echo "🚀 Iniciando Hotel Paradise con logging completo..."
echo "📄 Todos los logs se guardarán en $LOG_FILE"

# Limpiar log anterior
> "$LOG_FILE"

# Matar procesos en puertos 3000 y 8080
sudo kill -9 $(sudo lsof -ti:3000) 2>/dev/null
sudo kill -9 $(sudo lsof -ti:8080) 2>/dev/null

# Iniciar backend con logs
echo "📦 Iniciando backend..."
cd ~/Escritorio/hotel-booking/backend
npm start >> "$LOG_FILE" 2>&1 &
BACKEND_PID=$!

# Esperar que el backend inicie
echo "⏳ Esperando que backend inicie..."
sleep 5

# Iniciar frontend estático con logs
echo "🌐 Iniciando frontend..."
cd ~/Escritorio/hotel-booking
python3 -m http.server 8080 >> "$LOG_FILE" 2>&1 &
FRONTEND_PID=$!

echo "✅ Hotel Paradise iniciado!"
echo "📍 Backend: http://localhost:3000"
echo "📍 Frontend: http://localhost:8080"
echo "📍 Logs completos en: $LOG_FILE"
echo "📍 Health check: http://localhost:3000/health"

# Mantener script en ejecución para poder ver logs en tiempo real si se quiere
wait $BACKEND_PID $FRONTEND_PID
