import express from "express";
import path from "path";
import cors from "cors";
import fetch from "node-fetch";
import dotenv from "dotenv";

dotenv.config();

const app = express(); // declarar app primero
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors({
  origin: "http://localhost:8080",
  methods: ["GET", "POST"],
}));
app.use(express.json());
app.use('/backend/public', express.static(path.join(process.cwd(), 'public')));

// Resto del código (rutas, creación de booking, etc.)

// Datos de ejemplo de habitaciones
const roomsData = [
  { id: 1, name: "Doble", price: 350000, capacity: 2, image: "https://via.placeholder.com/80x60?text=Doble" },
  { id: 2, name: "Triple", price: 500000, capacity: 3, image: "https://via.placeholder.com/80x60?text=Triple" },
  { id: 3, name: "Cuádruple", price: 650000, capacity: 4, image: "https://via.placeholder.com/80x60?text=Cuadruple" }
];

// Endpoint para obtener habitaciones
app.get("/api/rooms", (req, res) => {
  res.json(roomsData);
});

// Endpoint para crear reserva y generar enlace de Wompi
app.post("/api/create-booking", async (req, res) => {
  try {
    const { name, email, checkIn, checkOut, rooms } = req.body;
    if (!name || !email || !checkIn || !checkOut || !rooms || rooms.length === 0) {
      return res.status(400).json({ ok: false, error: "Datos incompletos" });
    }

    // Calcular precio total
    const nights = Math.max(1, (new Date(checkOut) - new Date(checkIn)) / (1000*60*60*24));
    let total = 0;
    rooms.forEach(r => {
      const room = roomsData.find(room => room.id === r.id);
      if (room) total += room.price * nights;
    });
    total = Math.round(total * 100); // convertir a centavos

    // Crear reserva en Wompi
    const wompiResponse = await fetch(`${process.env.WOMPI_BASE_URL}/payment_links`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.WOMPI_PRIVATE_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name: `Reserva Hotel Paradise`,
        description: `Reserva de habitaciones`,
        amount_in_cents: total,
        currency: "COP",
        redirect_url: process.env.RETURN_URL,
        collect_shipping: false,
        collect_customer_legal_id: false,
        single_use: true
      })
    });

    const data = await wompiResponse.json();

    if (!data.data || !data.data.id) {
      return res.json({ ok: false, wompi_raw: data });
    }

    // URL de checkout Wompi
    const checkout_url = `https://checkout.wompi.co/l/${data.data.id}`;
    res.json({ ok: true, checkout_url, wompi_raw: data });

  } catch (err) {
    console.error("Error creando reserva:", err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🏨 Backend Hotel Paradise corriendo en http://localhost:${PORT}`);
});
